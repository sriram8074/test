package aemapi;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Objects;
import java.util.stream.StreamSupport;

public class AemJsonObject extends AemAccess {

  private JsonObject jsonObject;

  protected AemJsonObject(JsonObject object) {
    Objects.requireNonNull(object);
    jsonObject = object;
  }

  @Override
  public String toString() {
    return jsonObject.toString();
  }

  protected String getString(String keyToJsonObject, String keyToString) {
    JsonObject object = getJsonObject(keyToJsonObject);
    if (object == null) {
      return null;
    }
    JsonElement element = object.get(keyToString);
    return (element == null) ? null : element.getAsString();
  }

  protected JsonObject getJsonObject(String key) {
    JsonElement element = jsonObject.get(key);
    return (element == null) ? null : element.getAsJsonObject();
  }

  protected JsonArray getJsonArray(String key) {
    JsonElement element = jsonObject.get(key);
    return (element == null) ? null : element.getAsJsonArray();
  }

  protected String[] getStringArray(String key) {
    JsonArray array = getJsonArray(key);
    if (array == null) {
      return null;
    }
    return toStringArray(array);
  }

  private String[] toStringArray(JsonArray array) {
    return StreamSupport.stream(array.spliterator(), false)
        .map(JsonElement::getAsString).toArray(String[]::new);
  }
}