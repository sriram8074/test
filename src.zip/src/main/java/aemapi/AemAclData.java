package aemapi;

import java.util.HashSet;
import java.util.Set;
import lombok.Getter;

/**
 * Aem connector Acl data.
 *
 * @author Akshay_Bhujbale
 */
@Getter
public class AemAclData {
  private Set<String> allowPrincipal;
  private Set<String> denyPrincipal;
  private Set<String> cugPrincipal;
  private Set<String> effectiveAcl;

  /**
   * class constructor.
   *
   *
   */
  public AemAclData() {
    this.allowPrincipal = new HashSet<>();
    this.denyPrincipal = new HashSet<>();
    this.cugPrincipal = new HashSet<>();
    this.effectiveAcl = new HashSet<>();
  }

  public void setAllowPrincipal(String principal) {
    this.allowPrincipal.add(principal);
  }

  public void setDenyPrincipal(String principal) {
    this.denyPrincipal.add(principal);
  }

  public void setCugPrincipal(String principal) {
    this.cugPrincipal.add(principal);
  }

  public void setEffectiveAcl(Set<String> principalsSet) {
    this.effectiveAcl.addAll(principalsSet);
  }

  public void setEffectiveAcl(String principal) {
    this.effectiveAcl.add(principal);
  }
}

