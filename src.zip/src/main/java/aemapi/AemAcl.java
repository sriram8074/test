package aemapi;

import static aemapi.AemAccess.QUERY_BUILDER_ENDPOINT;
import static aemapi.AemAccess.getAemEndpoint;
import static aemapi.Constants.ADMIN;
import static aemapi.Constants.ADMINISTRATORS;
import static aemapi.Constants.HITS;
import static aemapi.Constants.INFINITY_JSON;
import static aemapi.Constants.ONE;
import static aemapi.Constants.PATH;
import static aemapi.Constants.PATH_DOT_EXACT;
import static aemapi.Constants.PROPERTY;
import static aemapi.Constants.PROPERTY_DOT_VALUE;
import static aemapi.Constants.P_DOT_LIMIT;
import static aemapi.Constants.REP_CUGPOLICY;
import static aemapi.Constants.REP_POICY;
import static aemapi.Constants.REP_PRINCIPALNAME;
import static aemapi.Constants.REP_USER;
import static aemapi.Constants.SLASH;
import static aemapi.Constants.TYPE;
import static java.lang.Boolean.TRUE;

import com.amazonaws.util.CollectionUtils;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.apache.http.client.utils.URIBuilder;

/**
 * AEM connector ACL.
 *
 * @author Akshay_Bhujbale
 */
public class AemAcl {

  /**
   * Method to get Acl jsonObject.
   *
   * @param aclPath acl path as input param
   * @return JsonObject jsonObject.
   */
  public static JsonObject getAcl(String aclPath) throws URISyntaxException, IOException {
    JsonObject json = new JsonObject();
    try {
      String path = getAemEndpoint() + aclPath;
      String jsonPath = path + INFINITY_JSON;
      //String encodedPath = URLEncoder.encode(path, StandardCharsets.UTF_8);
      json = AemAccess.getToJsonObject(
          new URIBuilder(jsonPath)
              .build());
    } catch (IOException | URISyntaxException e) {
      e.printStackTrace();
    }
    return json;
  }

  /**
   * Method to get page list for Acl check.
   *
   * @param path Input param
   * @param type Input param
   * @return List of string paths
   */
  public static List<String> getAclPageList(String path, String type)
      throws URISyntaxException, IOException {
    JsonObject json = AemAccess.getToJsonObject(
        new URIBuilder(getAemEndpoint() + QUERY_BUILDER_ENDPOINT)
            .addParameter(TYPE, type)
            .addParameter(PATH_DOT_EXACT, String.valueOf(Boolean.TRUE))
            .addParameter(PATH, path)
            .addParameter(P_DOT_LIMIT, "-1")
            .build());
    JsonArray jsonArray = (JsonArray) json.get(HITS);
    List<JsonObject> jsonObjects = new ArrayList<>();
    jsonArray.forEach(j -> jsonObjects.add((JsonObject) j));
    List<String> assetPaths;
    assetPaths = jsonObjects.stream()
        .filter(jsonObject -> jsonObject.get(PATH).toString()
            .replaceAll("\"", "")
            .startsWith("/"))
        .map(jsonObject -> jsonObject.get(PATH).toString().replaceAll("\"", ""))
        .collect(Collectors.toList());
    return assetPaths;
  }

  /**
   * Method to get AemAclData object.
   *
   * @param sourcePath input param
   * @return AemAclData object
   */
  public static AemAclData getAemAclData(String sourcePath) {
    AemAclData aemAclData = new AemAclData();
    getPaths(sourcePath).forEach(path -> {
      try {
        if (!getAclPageList(path, REP_CUGPOLICY).isEmpty()) {
          if (aemAclData.getCugPrincipal().isEmpty()) {
            getAclPageList(path, REP_CUGPOLICY).forEach(entryPath -> {
              try {
                parseCugJson(getAcl(entryPath), aemAclData);
              } catch (URISyntaxException | IOException e) {
                throw new RuntimeException(e);
              }
            });
          }
        }
        getAclPageList(path, REP_POICY).forEach(entryPath -> {
          try {
            effectiveAcl(getAcl(entryPath), aemAclData);
          } catch (URISyntaxException | IOException e) {
            throw new RuntimeException(e);
          }
        });
      } catch (URISyntaxException | IOException e) {
        throw new RuntimeException(e);
      }
    });
    if (CollectionUtils.isNullOrEmpty(aemAclData.getCugPrincipal())) {
      aemAclData.setEffectiveAcl(ADMIN);
      aemAclData.setEffectiveAcl(ADMINISTRATORS);
      aemAclData.setEffectiveAcl(aemAclData.getAllowPrincipal());
    } else {
      aemAclData.setEffectiveAcl(ADMIN);
      aemAclData.setEffectiveAcl(ADMINISTRATORS);
    }
    return aemAclData;
  }

  /**
   * Method to get effective acl.
   *
   * @param jsonObject input param
   * @param aemAclData input param
   */
  public static void effectiveAcl(JsonObject jsonObject, AemAclData aemAclData) {
    jsonObject.entrySet().forEach(jsonElementEntry -> {
      if (jsonElementEntry.getKey().contains(Constants.ALLOW)
          || jsonElementEntry.getKey().contains(Constants.DENY)) {
        jsonElementEntry.getValue().getAsJsonObject().getAsJsonArray(Constants.REP_PRIVILEGES)
            .forEach(jsonElement -> {
              if (jsonElement.toString().contains(Constants.JCR_ALL)
                  || jsonElement.toString().contains(Constants.JCR_READ)) {
                if (jsonElementEntry.getKey().contains(Constants.ALLOW)) {
                  if (!aemAclData.getDenyPrincipal().contains(jsonElementEntry.getValue()
                      .getAsJsonObject().get(Constants.REP_PRINCIPALNAME).getAsString())) {
                    aemAclData.setAllowPrincipal(jsonElementEntry.getValue().getAsJsonObject()
                        .get(Constants.REP_PRINCIPALNAME).getAsString());
                  }
                }
                if (jsonElementEntry.getKey().contains(Constants.DENY)) {
                  if (aemAclData.getCugPrincipal().contains(jsonElementEntry.getValue()
                      .getAsJsonObject().get(Constants.REP_PRINCIPALNAME).getAsString())) {
                    if (!aemAclData.getAllowPrincipal().contains(jsonElementEntry.getValue()
                        .getAsJsonObject().get(Constants.REP_PRINCIPALNAME).getAsString())) {
                      aemAclData.getEffectiveAcl().remove(jsonElementEntry.getValue()
                          .getAsJsonObject().get(Constants.REP_PRINCIPALNAME).getAsString());
                    }
                  }
                  if (!aemAclData.getAllowPrincipal().contains(jsonElementEntry.getValue()
                      .getAsJsonObject().get(Constants.REP_PRINCIPALNAME).getAsString())) {
                    aemAclData.setDenyPrincipal(jsonElementEntry.getValue().getAsJsonObject()
                        .get(Constants.REP_PRINCIPALNAME).getAsString());
                  }
                }
              }
            });
      }
    });
  }

  /**
   * Method to get.
   *
   * @param jsonObject input param
   * @param aemAclData input param
   */
  public static void parseCugJson(JsonObject jsonObject, AemAclData aemAclData) {
    jsonObject.get(Constants.CUG_PRINCIPALS).getAsJsonArray()
        .forEach(jsonElement -> {
          aemAclData.setCugPrincipal(jsonElement.getAsString());
        });
    aemAclData.setEffectiveAcl(aemAclData.getCugPrincipal());
  }

  /**
   * Method to check if principal is user.
   *
   * @param principalName input param
   * @return boolean
   */
  public static boolean isUser(String principalName) throws URISyntaxException, IOException {
    JsonObject json = AemAccess.getToJsonObject(
        new URIBuilder(getAemEndpoint() + QUERY_BUILDER_ENDPOINT)
            .addParameter(TYPE, REP_USER)
            .addParameter(PROPERTY, REP_PRINCIPALNAME)
            .addParameter(PROPERTY_DOT_VALUE,principalName)
            .addParameter(P_DOT_LIMIT, "-1")
            .build());
    JsonArray jsonArray = (JsonArray) json.get(HITS);
    List<JsonObject> jsonObjects = new ArrayList<>();
    jsonArray.forEach(j -> jsonObjects.add((JsonObject) j));
    List<String> assetPaths;
    assetPaths = jsonObjects.stream()
        .filter(jsonObject -> jsonObject.get(PATH).toString()
            .replaceAll("\"", "")
            .startsWith("/"))
        .map(jsonObject -> jsonObject.get(PATH).toString().replaceAll("\"", ""))
        .collect(Collectors.toList());
    if (assetPaths.isEmpty()) {
      return Boolean.FALSE;
    }
    return TRUE;
  }

  private static LinkedList<String> getPaths(String sourcePath) {
    LinkedList<String> paths = new LinkedList<>();
    try {
      String[] strArray = sourcePath.split(SLASH);
      paths.add(sourcePath);
      int iterate = strArray.length - ONE;
      while (iterate > ONE) {
        StringBuilder strBuilder = new StringBuilder();
        IntStream.range(ONE, iterate).forEach(index -> {
          strBuilder.append(SLASH);
          strBuilder.append(strArray[index]);
        });
        paths.add(strBuilder.toString());
        iterate--;
      }
      paths.add(SLASH);
    } catch (Exception e) {
      throw new RuntimeException();
    }
    return paths;
  }
}
