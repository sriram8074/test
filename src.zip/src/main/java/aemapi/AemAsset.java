package aemapi;

import static aemapi.AemAcl.getAemAclData;
import static aemapi.AemPage.getPathParameters;
import static aemapi.Constants.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.client.utils.URIBuilder;


public class AemAsset extends AemJsonObject {

  protected AemAsset(JsonObject object) {
    super(object);
  }
  private static int offset = ZERO;
  private static int results = ZERO;
  /**
   * Method to return AEM asset paths list.
   *
   * @param rootPaths root path input param
   * @return list of AEM asset paths.
   */
  public static List<String> getAssetPathsList(List<String> rootPaths)
      throws URISyntaxException, IOException {
    URIBuilder uriBuilder = new URIBuilder(getAemEndpoint() + QUERY_BUILDER_ENDPOINT);
    uriBuilder.addParameter(TYPE, DAM_ASSET);
    uriBuilder.addParameter(P_DOT_LIMIT, HUNDRED);
    getPathParameters(rootPaths).forEach((query,rootPath) -> {
      uriBuilder.addParameter(query,rootPath);
    });
    uriBuilder.addParameter(ONE_GROUP_DOT_P_DOT_OR, String.valueOf(Boolean.TRUE));
    uriBuilder.addParameter(P_DOT_OFFSET,String.valueOf(offset));
    JsonObject json = getToJsonObject( uriBuilder.build());
    results = Integer.parseInt(json.get(RESULTS).getAsString());
    offset = offset + results;
    JsonArray jsonArray = (JsonArray) json.get(HITS);
    List<JsonObject> jsonObjects = new ArrayList<>();
    jsonArray.forEach(j -> jsonObjects.add((JsonObject) j));
    List<String> assetPaths = new ArrayList<>();
    assetPaths.addAll(jsonObjects.stream()
        .filter(jsonObject -> jsonObject.get(PATH).toString()
            .replaceAll("\"", "")
            .startsWith(CONTENT_DAM))
        .map(jsonObject -> jsonObject.get(PATH).toString().replaceAll("\"", ""))
        .collect(Collectors.toList()));
    return assetPaths;
  }
  public static void resetCount(){
    offset = ZERO;
    results = ZERO;
  }
  /**
   * Method to get asset json.
   *
   * @return asset jsonObject.
   */
  public static JsonObject getAemAssetJson(String assetPath) {
    JsonObject json = new JsonObject();
    try {
      /*byte[] bytes = StringUtils.getBytesUtf8(assetPath);
      String utf8String = StringUtils.newStringUtf8(bytes);
      String newAssetPath = assetPath.replaceAll(" ","%20");
      String encodedPath = new String(assetPath0.getBytes(), StandardCharsets.UTF_8);
      String encodedPath = URLEncoder.encode(assetPath, StandardCharsets.UTF_8);*/
      String newAssetPath = assetPath.replaceAll("\\s+", "%20");
      String assetPath0 = AemAccess.getAemEndpoint() + newAssetPath + INFINITY_JSON;
      json = getToJsonObject(
          new URIBuilder(assetPath0)
              .build());
    } catch (IOException | URISyntaxException e) {
      e.printStackTrace();
    }
    return json;
  }

  /**
   * Method to get AemAssetData Object.
   *
   * @param assetPath aemConfiguration
   * @return AemAssetData Object.
   */
  public static AemAssetData getAemAssetData(String assetPath)
      throws IOException, URISyntaxException {
    return AemAssetData.builder().assetPath(assetPath)
        .assetMetadata(getAssetMetadata(getAemAssetJson(assetPath), assetPath))
        .assetInputStream(fileInputStream(assetPath))
        .aemAclData(getAemAclData(assetPath))
        .build();
  }

  /**
   * Method to get asset metadata.
   *
   * @param jsonObject assetPath aemConfiguration
   * @return Map of metadata.
   */
  private static Map<String, String> getAssetMetadata(JsonObject jsonObject, String assetPath) {
    List<String> fieldsList = new ArrayList<>();
    List<String> fieldsToCrawl = new ArrayList<>();
    fieldsList.addAll(List.of(Constants.getAssetProperties()));
    fieldsToCrawl.addAll(fieldsList);
    Map<String, String> metadata = new HashMap<>();
    jsonObject.entrySet().forEach(jsonElementEntry -> {
      if (jsonElementEntry.getValue().isJsonPrimitive()) {
        fieldsList.forEach(field -> {
          if (jsonElementEntry.getKey().equals(field)) {
            metadata.put(field, jsonElementEntry.getValue().getAsString());
            fieldsToCrawl.remove(field);
          }
        });
      }
    });
    metadata.put(EXTENSION, getFileExtension(assetPath));
    fieldsList.clear();
    fieldsList.addAll(fieldsToCrawl);
    if (!fieldsList.isEmpty()) {
      try {
        jsonObject.get(JCR_CONTENT).getAsJsonObject().entrySet().stream()
            .forEach(jsonElementEntry -> {
              if (jsonElementEntry.getValue().isJsonPrimitive()) {
                fieldsList.forEach(field -> {
                  if (jsonElementEntry.getKey().equals(field)) {
                    metadata.put(field, jsonElementEntry.getValue().getAsString());
                    fieldsToCrawl.remove(field);
                  }
                  if (field.equals(JCR_TITLE)) {
                    metadata.put(field, getFileName(assetPath));
                    fieldsToCrawl.remove(field);
                  }
                  if (field.equals(URI_PATH)) {
                    metadata.put(field, getSourceUri(assetPath));
                    fieldsToCrawl.remove(field);
                  }
                });
              }
            });
        if (fieldsToCrawl.contains(JCR_PRIMARY_TYPE)) {
          metadata.put(JCR_PRIMARY_TYPE,DAM_ASSET);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return metadata;
  }

  /**
   * Method to get asset source Uri.
   *
   * @param assetPath asset path input param
   * @return String uri.
   */
  private static String getSourceUri(String assetPath) {
    return getAemEndpoint() + API_ASSETS + getAssetDamPath(assetPath)
        + RENDITION_ORIGINAL;
  }

  /**
   * Method to get asset dam path.
   *
   * @param assetPath asset path input param
   * @return String asset dam path.
   */
  private static String getAssetDamPath(String assetPath) {
    try {
      return assetPath.split(CONTENT_DAM)[1];
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Method to get asset name.
   *
   * @param assetPath asset path input param
   * @return String asset name.
   */
  private static String getFileName(String assetPath) {
    String[] str = assetPath.split(SLASH);
    return  str[str.length - ONE];
  }

  /**
   * Method to get asset InputStream.
   *
   * @param assetPath asset path input param
   * @return InputStream.
   */
  public static InputStream fileInputStream(String assetPath) throws IOException {
    InputStream inputStream = null;
    /*try {
      System.out.println("****Asset PAht" + assetPath);
      String encodedPath = URLEncoder.encode(getAssetDamPath(assetPath),
          StandardCharsets.UTF_8);
      String newAssetPath = getAssetDamPath(assetPath).replaceAll("\\s+", "%20");
      String urlPath = getAemEndpoint() + API_ASSETS + newAssetPath + RENDITION_ORIGINAL;
      System.out.println("****Asset PAht" + urlPath);
      inputStream = getToInputStream(new URIBuilder(urlPath).build());
      is = new InflaterInputStream(inputStream);
    } catch (IOException e) {
    } catch (URISyntaxException e) {
      throw new RuntimeException(e);
    }
    StringBuffer sb = new StringBuffer();
    String inputLine = "";
    while ((inputLine = in.readLine()) != null) {
      sb.append(inputLine);
    }*/

    return null;
  }

  private static String getFileExtension(String assetPath) {
    return FilenameUtils.getExtension(assetPath);
  }
}