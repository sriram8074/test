package aemapi;

import java.io.InputStream;
import java.util.Map;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * AEM connector aem page data.
 *
 * @author Nitin
 */
@Builder
@Getter
@Setter
public class AemPageData {
  private String pagePath;
  private Map<String, String> metadata;
  private InputStream pageDataInputStream;
  private AemAclData aemAclData;
}
