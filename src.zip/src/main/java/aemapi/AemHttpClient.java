package aemapi;

import static aemapi.Constants.GRANT_TYPE;
import static aemapi.Constants.REDIRECT_URI;
import static aemapi.Constants.SLASH_AUTH_SLASH_TOKEN;
import static aemapi.Constants.alg;
import static aemapi.Constants.exp;
import static aemapi.Constants.iat;
import static aemapi.Constants.scope;
import static aemapi.Constants.sub;

import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONException;
import org.json.JSONObject;

public class AemHttpClient extends AemAccess {
  private static final AemHttpClient clientInstance = new AemHttpClient();
  private static final boolean isDebugEnabled = false;
  private static final String clientId = null;
  private static final String admin = null;
  private String accessToken;
  private String authType;
  private String userName;
  private String password;

  protected static String getBearerToken() {
    return "Bearer " + clientInstance.accessToken;
  }

  protected static String getAuthType() {
    return clientInstance.authType;
  }

  /**
   * Method to set authType.
   */
  public static void setAuthType(String authType) {
    Objects.requireNonNull(authType);
    clientInstance.authType = authType;
  }

  protected static String getUserName() {
    return clientInstance.userName;
  }

  /**
   * Method to set username.
   */
  public static void setUserName(String userName) {
    Objects.requireNonNull(userName);
    clientInstance.userName = userName;
  }

  protected static String getPassword() {
    return clientInstance.password;
  }

  /**
   * Method to set password.
   */
  public static void setPassword(String password) {
    Objects.requireNonNull(password);
    clientInstance.password = password;
  }

  protected static boolean isDebugEnabled() {
    return clientInstance.isDebugEnabled;
  }

  /**
   * Method to set access token.
   */
  public static void createAndSetAccessToken(String clientId, String clientSecret, String priKey,
      AemConfiguration aemConfiguration, String aemUrl)
      throws IOException, JSONException, InvalidKeySpecException, NoSuchAlgorithmException {
    PrivateKey privateKey = getPrivateKey(priKey);
    String jwtToken = generateJwtToken(privateKey, aemConfiguration);
    String accessToken = getAccessToken(clientId, clientSecret, aemUrl, jwtToken);
    Objects.requireNonNull(accessToken);
    clientInstance.accessToken = accessToken;
    // _verifyToken();
  }

  /**
   * Method to fetch AEM access token.
   *
   * @param clientId     - AEM client ID
   * @param clientSecret - AEM client secret
   * @param aemUrl       - AEM url
   * @param token        - JWT token
   * @return - AEM access token
   */
  public static String getAccessToken(String clientId, String clientSecret, String aemUrl,
      String token)
      throws IOException, JSONException {
    String imsExchange = aemUrl + SLASH_AUTH_SLASH_TOKEN;
    URL obj = new URL(imsExchange);
    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
    // add request header
    con.setRequestMethod("POST");
    // Add parameters to request
    String urlParameters =
        "client_id=" + clientId + "&client_secret=" + clientSecret + "&assertion=" + token
            + "&grant_type=" + GRANT_TYPE + "&redirect_uri" + REDIRECT_URI;

    // Send post request
    con.setDoOutput(true);
    DataOutputStream wr = new DataOutputStream(con.getOutputStream());
    wr.writeBytes(urlParameters);
    wr.flush();
    wr.close();
    int responseCode = con.getResponseCode();
    System.out.println("Sending 'POST' request to URL: " + imsExchange);
    System.out.println("Post parameters: " + urlParameters);
    System.out.println("Response Code: " + responseCode);
    boolean responseError = false;
    InputStream is;
    if (responseCode < HttpsURLConnection.HTTP_BAD_REQUEST) {
      is = con.getInputStream();
    } else {
      is = con.getErrorStream();
      responseError = true;
    }
    BufferedReader in = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
    String inputLine;
    StringBuilder response = new StringBuilder();
    while ((inputLine = in.readLine()) != null) {
      response.append(inputLine);
    }
    in.close();
    if (responseError) {
      System.out.println(response.toString());
    }
    JSONObject jsonObject = new JSONObject(response.toString());
    return jsonObject.getString("access_token");
  }

  /**
   * Method to return AEM JWT token.
   *
   * @param privateKey       - AEM private key
   * @param aemConfiguration - AEM configuration.
   * @return - AEM JWT token
   */
  public static String generateJwtToken(PrivateKey privateKey, AemConfiguration aemConfiguration) {
    String token = null;

    String aemUrl = aemConfiguration.getAemUrl();
    String clientId1 = aemConfiguration.getClientId();
    final String aud = aemUrl + SLASH_AUTH_SLASH_TOKEN;
    try {
      Map<String, Object> claims = new LinkedHashMap<>();


      claims.put("aud", aud);
      claims.put("iss", clientId1);
      claims.put("sub", sub);
      claims.put("iat", iat);
      claims.put("exp", exp);
      claims.put("scope", scope);
      claims.put("cty", "code");
      claims.put("alg", alg);
      token = Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS256, privateKey)
          .compact();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return token;
  }

  private static PrivateKey getPrivateKey(String rsaPrivateKey)
      throws NoSuchAlgorithmException, InvalidKeySpecException {
    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(
        Base64.getDecoder().decode(rsaPrivateKey));
    KeyFactory kf = KeyFactory.getInstance("RSA");
    return kf.generatePrivate(keySpec);
  }
}