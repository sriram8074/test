package aemapi;

import com.amazonaws.services.dynamodbv2.xspec.S;

public final class Constants {

  public static final String INFINITY_JSON = ".infinity.json";
  public static final String REDIRECT_URI = "http://localhost:4505/we-retail";
  public static final String GRANT_TYPE = "urn:ietf:params:oauth:grant-type:jwt-bearer";
  public static final String SLASH_AUTH_SLASH_TOKEN = "/oauth/token";
  public static final String OAUTH = "Oauth";
  public static final String BASIC = "Basic";
  public static final String alg = "HS256";
  public static final String scope = "profile,replicate";
  public static final String sub = "admin";
  public static final long iat = System.currentTimeMillis();
  public static final long exp = iat + 60000;
  public static final String CONTENT_DAM = "/content/dam";
  public static final String RENDITION_ORIGINAL = "/renditions/original";
  public static final String JCR_CONTENT = "jcr:content";
  public static final String DOT_HTML = ".html";
  public static final String REP_POICY = "rep:ACL";
  public static final String REP_CUGPOLICY = "rep:CugPolicy";

  public static final String DENY = "deny";
  public static final String ALLOW = "allow";
  public static final String REP_PRIVILEGES = "rep:privileges";
  public static final String JCR_READ = "jcr:read";
  public static final String JCR_ALL = "jcr:all";
  public static final String REP_PRINCIPALNAME = "rep:principalName";
  public static final String CUG_PRINCIPALS = "rep:principalNames";
  public static final String JCR_UUID = "jcr:uuid";
  public static final String JCR_TITLE = "jcr:title";
  public static final String URI_PATH = "uri_path";
  public static final String JCR_CREATED_BY = "jcr:createdBy";
  public static final String CQ_LAST_REPLICATED_BY = "cq:lastReplicatedBy";
  public static final String CQ_LAST_REPLICATED = "cq:lastReplicated";
  public static final String JCR_PRIMARY_TYPE = "jcr:primaryType";
  public static final String JCR_CREATED = "jcr:created";
  public static final String CQ_LAST_MODIFIED = "cq:lastModified";
  public static final String CQ_TEMPLATE = "cq:template";

  public static String[] getPageProperties() {
    return PAGE_PROPERTIES.clone();
  }

  private static String[] PAGE_PROPERTIES = {JCR_UUID, JCR_TITLE, JCR_CREATED_BY,
      CQ_TEMPLATE,
      CQ_LAST_REPLICATED_BY, URI_PATH, CQ_LAST_REPLICATED, JCR_PRIMARY_TYPE, JCR_CREATED,
      CQ_LAST_MODIFIED};
  public static final String JCR_LAST_MODIFIED_BY = "jcr:lastModifiedBy";
  public static final String JCR_LAST_MODIFIED = "jcr:lastModified";

  public static String[] getAssetProperties() {
    return ASSET_PROPERTIES.clone();
  }

  private static String[] ASSET_PROPERTIES = {JCR_UUID, JCR_TITLE, JCR_CREATED_BY,
      CQ_LAST_REPLICATED_BY, CQ_LAST_REPLICATED, URI_PATH, JCR_PRIMARY_TYPE, JCR_CREATED,
      JCR_LAST_MODIFIED_BY, JCR_LAST_MODIFIED};
  public static final String API_ASSETS = "/api/assets";
  public static final String EXTENSION = "extension";
  public static final String TYPE = "type";
  public static final String PATH_DOT_EXACT = "path.exact";
  public static final String PATH = "path";
  public static final String P_DOT_LIMIT = "p.limit";
  public static final String HITS = "hits";
  public static final String CQ_PAGE = "cq:Page";
  public static final String DAM_ASSET = "dam:Asset";
  public static final String PROPERTY = "property";
  public static final String JCR_CONTENT_CQ_REPLICATIONACTION = "jcr:content/cq"
      + ":lastReplicationAction";
  public static final String PROPERTY_DOT_VALUE = "property.value";
  public static final String ACTIVATE = "Activate";
  public static final String SLASH_CONTENT = "/content";
  public static final int ZERO = 0;
  public static final String REP_USER = "rep:User";
  public static final String SLASH = "/";
  public static final int ONE = 1;
  public static final String SPACE = "";
  public static final String INVALID_PATH_REGEX = ".*[`\\s@#%^&?*,<>\\<>|\":].*";
  public static final String ADMIN = "admin";
  public static final String ADMINISTRATORS = "administrators";
  public static final String ONE_GROUP_DOT_P_DOT_OR = "1_group.p.or";
  public static final String P_DOT_OFFSET = "p.offset";
  public static final String TOTAL = "total";
  public static final String RESULTS = "results";
  public static final String HUNDRED = "100";
  public static final String ONE_GROUP_DOT = "1_group.";
  public static final String _PATH  = "_path";
}