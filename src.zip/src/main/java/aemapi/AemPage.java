package aemapi;

import static aemapi.AemAcl.getAemAclData;
import static aemapi.Constants.*;

import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.util.CollectionUtils;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import org.apache.http.client.utils.URIBuilder;

public class AemPage extends AemJsonObject {
  protected AemPage(JsonObject object) {
    super(object);
  }
  private static int offset = ZERO;
  private static int results = ZERO;

  private static StringBuilder componentData;

  public static Map<String,String>  getPathParameters(List<String> rootPaths){
      Map<String,String> pathParametersMap = new HashMap<>();
      AtomicInteger index = new AtomicInteger(ONE);
      rootPaths.forEach(rootPath->{
        pathParametersMap.put(ONE_GROUP_DOT+ index.get() + _PATH,rootPath);
        index.set(index.get() + ONE);
      });
      return pathParametersMap;
  }

  /**
   * Method to return AEM Page paths list.
   *
   * @param rootPaths List
   * @return list of AEM page paths.
   */
  public static List<String> getPagePathsList(List<String> rootPaths)
      throws URISyntaxException, IOException {
    URIBuilder uriBuilder = new URIBuilder(getAemEndpoint()
          + QUERY_BUILDER_ENDPOINT);
    uriBuilder.addParameter(TYPE, CQ_PAGE);
    uriBuilder.addParameter(P_DOT_LIMIT, HUNDRED);
    getPathParameters(rootPaths).forEach((query,rootPath) -> {
      uriBuilder.addParameter(query,rootPath);
    });
    uriBuilder.addParameter(ONE_GROUP_DOT_P_DOT_OR, String.valueOf(Boolean.TRUE));
    uriBuilder.addParameter(P_DOT_OFFSET,String.valueOf(offset));
    JsonObject json = getToJsonObject( uriBuilder.build());
    results = Integer.parseInt(json.get(RESULTS).getAsString());
    offset = offset + results;
    JsonArray jsonArray = (JsonArray) json.get(HITS);
    List<JsonObject> jsonObjects = new ArrayList<>();
    jsonArray.forEach(j -> jsonObjects.add((JsonObject) j));
    List<String> pagePaths = new ArrayList<>();
    pagePaths.addAll(jsonObjects.stream()
        .filter(jsonObject -> jsonObject.get(PATH).toString()
            .replaceAll("\"", "")
            .startsWith(SLASH_CONTENT))
        .map(jsonObject -> jsonObject.get(PATH).toString().replaceAll("\"", ""))
        .collect(Collectors.toList()));
    return pagePaths;
  }

  public static void resetCount(){
    offset = ZERO;
    results = ZERO;
  }

  /**
   * Method to return AEM Page paths list.
   *
   * @param pagePath page path
   * @return list of AEM page paths.
   */
  public static JsonObject getAemPageJson(String pagePath) {
    JsonObject json = new JsonObject();
    try {
      String pagePath0 = AemAccess.getAemEndpoint() + pagePath + Constants.INFINITY_JSON;
      //String encodedPath = URLEncoder.encode(pPath, StandardCharsets.UTF_8);
      json = getToJsonObject(
          new URIBuilder(pagePath0)
              .build());
    } catch (IOException | URISyntaxException e) {
      e.printStackTrace();
    }
    return json;
  }

  /**
   * Method to return AemPageData Object.
   *
   * @param pagePath         input param Page path
   * @param aemConfiguration input param aem configuration
   * @return list of AEM page paths.
   */
  public static AemPageData getAemPageData(String pagePath, AemConfiguration aemConfiguration)
      throws URISyntaxException, IOException {
    return AemPageData.builder().pagePath(pagePath)
        .metadata(getAemPageMetadata(getAemPageJson(pagePath), pagePath))
        .pageDataInputStream(
            getPageDataInputStream(getAemPageJson(pagePath), pagePath, aemConfiguration))
        .aemAclData(getAemAclData(pagePath))
        .build();
  }

  /**
   * Method to return Aem metadta map.
   *
   * @param jsonObject Input param json object
   * @param pagePath   input param page path
   * @return list of AEM page paths.
   */
  private static Map<String, String> getAemPageMetadata(JsonObject jsonObject, String pagePath) {
    List<String> fieldsList = new ArrayList<>();
    List<String> fieldsToCrawl = new ArrayList<>();
    fieldsList.addAll(List.of(Constants.getPageProperties()));
    fieldsToCrawl.addAll(fieldsList);
    Map<String, String> metadata = new HashMap<>();
    if (Objects.nonNull(jsonObject) && Objects.nonNull(jsonObject.get(JCR_CONTENT))) {
      jsonObject.entrySet().forEach(jsonElementEntry -> {
        if (jsonElementEntry.getValue().isJsonPrimitive()) {
          fieldsList.forEach(field -> {
            if (jsonElementEntry.getKey().equals(field)) {
              metadata.put(field, jsonElementEntry.getValue().getAsString());
              fieldsToCrawl.remove(field);
            }
          });
        }
      });
      fieldsList.clear();
      fieldsList.addAll(fieldsToCrawl);
      if (!fieldsList.isEmpty()) {
        try {
          jsonObject.get(JCR_CONTENT).getAsJsonObject().entrySet().stream()
              .forEach(jsonElementEntry -> {
                if (jsonElementEntry.getValue().isJsonPrimitive()) {
                  fieldsList.forEach(field -> {
                    if (jsonElementEntry.getKey().equals(field)) {
                      metadata.put(field, jsonElementEntry.getValue().getAsString());
                      fieldsToCrawl.remove(field);
                    }
                    if (field.equals(URI_PATH)) {
                      metadata.put(field, getPageSourceUri(pagePath));
                      fieldsToCrawl.remove(field);
                    }
                  });
                }
              });
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }
    if (fieldsToCrawl.contains(JCR_TITLE)) {
      metadata.put(JCR_TITLE,getPageName(pagePath));
    }
    if (fieldsToCrawl.contains(JCR_PRIMARY_TYPE)) {
      metadata.put(JCR_PRIMARY_TYPE,CQ_PAGE);
    }
    return metadata;
  }

  /**
   * Method to return page data input stream.
   *
   * @param jsonObject       json object.
   * @param pagePath         page path.
   * @param aemConfiguration aem configuration.
   * @return InputStream page data input stream.
   */
  private static InputStream getPageDataInputStream(JsonObject jsonObject, String pagePath,
                                                    AemConfiguration aemConfiguration) {
    componentData = new StringBuilder();
    InputStream inputStream = null;
    Map<String,List<String>> componentFieldsMap
        = new HashMap<>(getPageComponent(aemConfiguration));
    if (Objects.nonNull(jsonObject) && Objects.nonNull(jsonObject.get(JCR_CONTENT))) {
      if (!CollectionUtils.isNullOrEmpty(componentFieldsMap.keySet())) {
        try {
          pageComponentData(jsonObject.get(JCR_CONTENT).getAsJsonObject(), componentFieldsMap);
          if (componentData.length() > ZERO) {
            inputStream = new ByteArrayInputStream(componentData.toString()
                .getBytes(StandardCharsets.UTF_8));
          }
        } catch (NullPointerException e) {
          e.printStackTrace();
        }
      } else {
        inputStream = getPageHtml(getPageSourceUri(pagePath));
      }
    }
    return inputStream;
  }

  private static void pageComponentData(JsonObject jsonObject,
                                        Map<String,List<String>> componentFieldsMap) {
    jsonObject.entrySet()
        .stream()
        .forEach(jsonElementEntry -> {
          if (jsonElementEntry.getValue().isJsonObject()) {
            componentFieldsMap.forEach((component, fields) -> {
              if (jsonElementEntry.getValue().toString().contains(component)) {
                componentData.append(getFieldData(jsonElementEntry.getValue()
                    .getAsJsonObject(), fields));
              }
            });
            pageComponentData(jsonElementEntry.getValue().getAsJsonObject(),componentFieldsMap);
          }
        });
  }

  /**
   * Method to return page data input stream.
   *
   * @param jsonObject Json object Input param
   * @param fields     List of fields
   * @return String field data.
   */
  private static String getFieldData(JsonObject jsonObject, List<String> fields) {
    StringBuilder str = new StringBuilder();
    fields.forEach(field -> {
      jsonObject.entrySet().stream().forEach(jsonElementEntry -> {
        if (jsonElementEntry.getKey().contains(field)) {
          try {
            str.append(jsonElementEntry.getValue().toString());
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      });
    });
    return str.toString();
  }

  /**
   * Method to return page inputStream.
   *
   * @param urlPath page path url
   * @return inputStream
   */
  private static InputStream getPageHtml(String urlPath) {
    InputStream inputStream = null;
    try {
      //String encodedPath = URLEncoder.encode(getAssetDamPath(assetPath), StandardCharsets.UTF_8);
      inputStream = getToInputStream(new URIBuilder(urlPath).build());
    } catch (IOException e) {
      // handles IO exceptions
    } catch (URISyntaxException e) {
      throw new RuntimeException(e);
    }
    return inputStream;
  }

  /**
   * Method to return page source uri.
   *
   * @param pagePath page path
   * @return String source uri
   */
  private static String getPageSourceUri(String pagePath) {
    return AemAccess.getAemEndpoint() + pagePath + DOT_HTML;
  }

  /**
   * Method to return Map of page component and fields.
   *
   * @param aemConfiguration aem configuration
   * @return Map of component and List of fields.
   */
  private static Map<String,List<String>> getPageComponent(AemConfiguration aemConfiguration) {
    Map<String,List<String>> componentFieldsMap = new HashMap<>();
    if (!CollectionUtils.isNullOrEmpty(aemConfiguration.getPageComponents())) {
      aemConfiguration.getPageComponents().stream().forEach(componentField -> {
        componentField.keySet().forEach(component -> {
          componentFieldsMap.put(component, (List<String>) componentField.get(component));
        });
      });
    }
    return componentFieldsMap;
  }

  private static String getPageName(String pagePath) {
    String[] str = pagePath.split(SLASH);
    return  str[str.length - ONE];
  }
}