package aemapi;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Aem connector Aem asset data.
 *
 * @author Nitin
 */
@Builder
@Getter
@Setter
public class AemAssetData {

  private String assetPath;
  private InputStream assetInputStream;
  private Map<String, String> assetMetadata;
  private Map<String, String> metaDataMap = new HashMap<>();
  private AemAclData aemAclData;

}
