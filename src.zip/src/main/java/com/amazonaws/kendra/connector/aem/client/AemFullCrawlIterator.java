package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.kendra.connector.aem.services.AemService;
import com.amazonaws.kendra.connector.sdk.model.item.ItemInfo;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Iterator class for AEM connector.
 *
 * @author omkar_phadtare
 */
public class AemFullCrawlIterator implements AemIterator {

  private boolean isQueueLoaded = Boolean.FALSE;
  private final Queue<ItemInfo> itemInfoQueue;
  private final AemConfiguration aemConfiguration;
  private final AemService aemService;

  /**
   * Constructor for FullCrawlIterator.
   */
  public AemFullCrawlIterator(AemService aemService, AemConfiguration aemConfiguration) {
    this.aemService = aemService;
    this.aemConfiguration = aemConfiguration;
    this.itemInfoQueue = new ConcurrentLinkedQueue<>();
  }

  @Override
  public boolean hasNext() {
      this.itemInfoQueue.addAll(aemService.getAemEntities(aemConfiguration, 0));
    return !this.itemInfoQueue.isEmpty();
  }

  @Override
  public ItemInfo next() {
    return this.itemInfoQueue.remove();
  }
}