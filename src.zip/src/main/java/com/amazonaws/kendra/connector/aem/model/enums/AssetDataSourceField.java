package com.amazonaws.kendra.connector.aem.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enum for datasource fields of assets.
 *
 * @author omkar_phadtare
 */
@AllArgsConstructor
public enum AssetDataSourceField {
  aem_asset_title("aem_asset_title"),
  aem_asset_source_uri("aem_asset_source_uri"),
  aem_asset_createdBy("aem_asset_createdBy"),
  aem_asset_type("aem_asset_type"),
  aem_asset_createdAt("aem_asset_createdAt"),
  aem_asset_lastModified("aem_asset_lastModified");

  @Getter
  private final String type;
}