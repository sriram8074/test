package com.amazonaws.kendra.connector.aem.client;

import static aemapi.Constants.CQ_LAST_MODIFIED;
import static aemapi.Constants.CQ_PAGE;
import static aemapi.Constants.CQ_TEMPLATE;
import static aemapi.Constants.DAM_ASSET;
import static aemapi.Constants.JCR_CREATED;
import static aemapi.Constants.JCR_CREATED_BY;
import static aemapi.Constants.JCR_LAST_MODIFIED;
import static aemapi.Constants.JCR_PRIMARY_TYPE;
import static aemapi.Constants.JCR_TITLE;
import static aemapi.Constants.JCR_UUID;
import static aemapi.Constants.URI_PATH;
import static com.amazonaws.kendra.connector.aem.util.Constants.CHANGE_LOG;
import static com.amazonaws.kendra.connector.aem.util.Constants.FULL_CRAWL;
import static com.amazonaws.kendra.connector.aem.util.Constants.GROUP;
import static com.amazonaws.kendra.connector.aem.util.Constants.ITEM_PRINCIPAL;
import static com.amazonaws.kendra.connector.aem.util.Constants.USER;

import aemapi.AemAsset;
import aemapi.AemPage;
import com.amazonaws.kendra.connector.aem.model.item.AssetItem;
import com.amazonaws.kendra.connector.aem.model.item.PageItem;
import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.kendra.connector.aem.services.AemService;
import com.amazonaws.kendra.connector.aem.token.AemChangeLogToken;
import com.amazonaws.kendra.connector.aem.token.AemChangeLogTokenSerializer;
import com.amazonaws.kendra.connector.aem.util.AemCollaborationInfo;
import com.amazonaws.kendra.connector.sdk.client.RepositoryClient;
import com.amazonaws.kendra.connector.sdk.exception.KendraConnectorException;
import com.amazonaws.kendra.connector.sdk.log.DocumentId;
import com.amazonaws.kendra.connector.sdk.log.MaskedJson;
import com.amazonaws.kendra.connector.sdk.model.ConnectionStatus;
import com.amazonaws.kendra.connector.sdk.model.item.Item;
import com.amazonaws.kendra.connector.sdk.model.item.ItemInfo;
import com.amazonaws.kendra.connector.sdk.model.repository.RepositoryConfiguration;
import com.amazonaws.services.kendra.model.Principal;
import com.amazonaws.services.kendra.model.ReadAccessType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.CustomLog;
import lombok.NoArgsConstructor;
import org.json.JSONException;
import org.json.JSONObject;


/**
 * Client class for AEM connector.
 *
 * @author omkar_phadtare
 */
@CustomLog
@NoArgsConstructor
public class AemClient implements RepositoryClient {

  private AemChangeLogTokenSerializer serializer;
  private AemConfiguration aemConfiguration;
  private AemIterator aemChangeLogIterator;
  private AemIterator aemFullCrawlIterator;
  private AemService aemService;
  private long changeLogIteratorInitTimestamp = 0;

  @Override
  public ConnectionStatus testConnection() {
    String jsonString = "";
    try {
      jsonString = new JSONObject()
          .put("userName", aemConfiguration.getUsername())
          .put("hostUrl", aemConfiguration.getAemUrl()).toString();
      log.info(new MaskedJson(jsonString), "testing connection with aem configuration");
      boolean connected = aemService.testConnection(aemConfiguration);
      return ConnectionStatus.builder().isConnected(connected).build();
    } catch (KendraConnectorException kce) {
      return ConnectionStatus.builder().isConnected(false).statusMessage(kce.getMessage()).build();
    } catch (JSONException jex) {
      log.error("Error creating Aem configuration log " + jsonString, jex);
      return ConnectionStatus.builder().isConnected(false).statusMessage(jex.getMessage()).build();
    }
  }

  @Override
  public Optional<Item> getItem(ItemInfo itemInfo) {
    Optional<Item> resultItem;
    if (itemInfo.getMetadata().get(JCR_PRIMARY_TYPE).equals(CQ_PAGE)) {
      resultItem = buildPageItem(itemInfo, aemConfiguration);
      if (resultItem.isPresent()) {
        PageItem pageItem = (PageItem) resultItem.get();
        log.info(new DocumentId(pageItem.getDocumentId(), pageItem.getAemPageTitle(),
            pageItem.getAemPageSourceUri()), "Successfully get Page item from AEM");
      }
    } else if (itemInfo.getMetadata().get(JCR_PRIMARY_TYPE).equals(DAM_ASSET)) {
      resultItem = buildAssetItem(itemInfo, aemConfiguration);
      if (resultItem.isPresent()) {
        AssetItem assetItem = (AssetItem) resultItem.get();
        log.info(new DocumentId(assetItem.getDocumentId(), assetItem.getAemAssetTitle(),
            assetItem.getAemAssetUuid()), "Successfully get Asset item from AEM");
      }
    } else {
      resultItem = Optional.empty();
    }
    return resultItem;
  }

  @Override
  public Iterator<ItemInfo> listItems() {
    this.changeLogIteratorInitTimestamp = Date.from(Instant.now()).getTime();
    return this.aemFullCrawlIterator;
  }

  @Override
  public Iterator<ItemInfo> listChangeLogItems(java.lang.String changeLogToken) {
    AemChangeLogToken token = serializer.deSerialize(changeLogToken);
    this.changeLogIteratorInitTimestamp = Date.from(Instant.now()).getTime();
    this.aemChangeLogIterator.initialize(Long.toString(token.getLastCrawlTime()));
    return this.aemChangeLogIterator;
  }

  @Override
  public void resetAndInitialize(RepositoryConfiguration repositoryConfiguration) {
    log.info("Aem Connector resentAndInitialize called");
    this.aemConfiguration = AemConfiguration.of(repositoryConfiguration);
    serializer = AemChangeLogTokenSerializer.builder().objectMapper(new ObjectMapper()).build();
    this.aemService = new AemService();
    this.aemFullCrawlIterator =
        AemIteratorFactory
            .getInstance(FULL_CRAWL, this.aemConfiguration, this.aemService);
    this.aemChangeLogIterator =
        AemIteratorFactory
            .getInstance(CHANGE_LOG, this.aemConfiguration, this.aemService);
    AemPage.resetCount();
    AemAsset.resetCount();
    log.info("AEM Connector Configured.");

  }

  /**
   * Method to fetch latest change log token.
   *
   * @return latest change log token.
   */
  @Override
  public Optional<String> getLatestChangeLogToken() {
    this.changeLogIteratorInitTimestamp =
        this.changeLogIteratorInitTimestamp != 0
            ? this.changeLogIteratorInitTimestamp : Date.from(Instant.now()).getTime();

    AemChangeLogToken changeLogToken =
        AemChangeLogToken.builder()
            .lastCrawlTime(changeLogIteratorInitTimestamp)
            .repositoryConfigurations(this.aemConfiguration.getRepositoryConfigurations())
            .additionalProperties(this.aemConfiguration.getAdditionalProperties())
            .build();

    return Optional.of(serializer.serialize(changeLogToken));
  }

  /**
   * Method to check isCrawlConfigurationUpdatedForChangeLog.
   *
   * @param previousChangeLogToken input parameter
   * @return boolean
   */
  public boolean isCrawlConfigurationUpdatedForChangeLog(String previousChangeLogToken) {
    return Boolean.FALSE;
  }

  /**
   * Method to build page item.
   *
   * @param itemInfo         the item info
   * @param aemConfiguration input parameter.
   * @return boolean optional
   */
  public Optional<Item> buildPageItem(ItemInfo itemInfo, AemConfiguration aemConfiguration) {
    AemConfiguration pageAemConfiguration = aemConfiguration;
    InputStream inputStream = AemService.getPageItemIdInputStreamMap().remove(itemInfo.getItemId());
    String aemPagePath  = itemInfo.getItemId();
    String aemPageUuid = itemInfo.getMetadata().get(JCR_UUID);
    String aemPageTitle = itemInfo.getMetadata().get(JCR_TITLE);
    String aemPageSourceUri = itemInfo.getMetadata().get(URI_PATH);
    String aemAssetCreatedBy = itemInfo.getMetadata().get(JCR_CREATED_BY);
    String aemPageTemplate = itemInfo.getMetadata().get(CQ_TEMPLATE);
    String aemEntityType = itemInfo.getMetadata().get(JCR_PRIMARY_TYPE);
    String aemPageCreatedAt = itemInfo.getMetadata().get(JCR_CREATED);
    String aemPageLastModified = itemInfo.getMetadata().get(CQ_LAST_MODIFIED);
    return Optional.ofNullable(
        PageItem.builder().aemConfiguration(pageAemConfiguration)
            .aemPagePath(aemPagePath)
            .aemPageUuid(aemPageUuid)
            .inputStream(inputStream).aemPageTitle(aemPageTitle)
            .aemPageSourceUri(aemPageSourceUri)
            .aemPageCreatedBy(aemAssetCreatedBy)
            .aemPageTemplate(aemPageTemplate)
            .aemEntityType(aemEntityType).aemPageCreatedAt(aemPageCreatedAt)
            .aemPageLastModified(aemPageLastModified)
            .principals(getPrincipals(itemInfo.getMetadata().remove(ITEM_PRINCIPAL)))
            .customMetadata(itemInfo.getMetadata())
            .build());
  }

  /**
   * Method to build asset item.
   *
   * @param itemInfo         the item info
   * @param aemConfiguration input parameter.
   * @return boolean optional
   */
  public Optional<Item> buildAssetItem(ItemInfo itemInfo, AemConfiguration aemConfiguration) {
    AemConfiguration assetAemConfiguration = aemConfiguration;
    String aemAssetPath = itemInfo.getItemId();
    String aemAssetUuid = itemInfo.getItemId();
    String aemAssetTitle = itemInfo.getMetadata().get(JCR_TITLE);
    InputStream inputStream = new ByteArrayInputStream(
        aemAssetTitle.getBytes(StandardCharsets.UTF_8));
    String aemAssetSourceUri = itemInfo.getMetadata().get(URI_PATH);
    String aemAssetCreatedBy = itemInfo.getMetadata().get(JCR_CREATED_BY);
    String aemAssetType = itemInfo.getMetadata().get(JCR_PRIMARY_TYPE);
    String aemAssetCreatedAt = itemInfo.getMetadata().get(JCR_CREATED);
    String aemAssetLastModified = itemInfo.getMetadata().get(JCR_LAST_MODIFIED);
    return Optional.ofNullable(
        AssetItem.builder().aemConfiguration(assetAemConfiguration)
            .aemAssetPath(aemAssetPath)
            .aemAssetUuid(aemAssetUuid)
            .inputStream(inputStream)
            .aemAssetSourceUri(aemAssetSourceUri)
            .aemAssetTitle(aemAssetTitle)
            .aemAssetCreatedBy(aemAssetCreatedBy)
            .aemAssetType(aemAssetType)
            .aemAssetCreatedAt(aemAssetCreatedAt)
            .aemAssetLastModified(aemAssetLastModified)
            .principals(getPrincipals(itemInfo.getMetadata().remove(ITEM_PRINCIPAL)))
            .build());
  }

  /**
   * Method to get principals.
   *
   * @param accessibleBy input parameter
   * @return List
   */
  public List<Principal> getPrincipals(String accessibleBy) {
    List<Principal> principalList = new ArrayList<>();
    try {
      if (Objects.nonNull(accessibleBy)) {
        AemCollaborationInfo aemCollaborationInfo = new Gson()
            .fromJson(accessibleBy, AemCollaborationInfo.class);
        if (Objects.nonNull(aemCollaborationInfo)) {
          aemCollaborationInfo.getAllowUsers().forEach(userName -> {
            Principal principal = new Principal();
            principal.withAccess(ReadAccessType.ALLOW);
            principal.withName(userName);
            principal.withType(USER);
            principalList.add(principal);
          });
          aemCollaborationInfo.getDenyUsers().forEach(userName -> {
            Principal principal = new Principal();
            principal.withAccess(ReadAccessType.DENY);
            principal.withName(userName);
            principal.withType(USER);
            principalList.add(principal);
          });
          String dataSourceId = aemConfiguration.getRepositoryConfiguration().getRepositoryId();
          aemCollaborationInfo.getAllowGroups().forEach(groupName -> {
            Principal principal = new Principal();
            principal.withAccess(ReadAccessType.ALLOW);
            principal.withName(groupName);
            principal.withType(GROUP);
            principal.setDataSourceId(dataSourceId);
            principalList.add(principal);
          });
          aemCollaborationInfo.getDenyGroups().forEach(groupName -> {
            Principal principal = new Principal();
            principal.withAccess(ReadAccessType.DENY);
            principal.withName(groupName);
            principal.withType(GROUP);
            principal.setDataSourceId(dataSourceId);
            principalList.add(principal);
          });
        }
      }
    } catch (Exception e) {
      log.debug("Exception occurred while parsing principles : " + e.getMessage());
    }
    return principalList;
  }
}