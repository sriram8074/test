package com.amazonaws.kendra.connector.aem;

import static com.amazonaws.kendra.connector.aem.util.Constants.AEM_CONNECTOR;
import static com.amazonaws.kendra.connector.aem.util.Constants.MAX_DOCS_PER_CRAWL;
import static com.amazonaws.kendra.connector.aem.util.Constants.SERVER_PORT_NUMBER;
import static com.amazonaws.kendra.connector.aem.util.Constants.THREAD_COUNT;

import com.amazonaws.kendra.connector.aem.client.AemClientFactory;
import com.amazonaws.kendra.connector.sdk.Application;
import com.amazonaws.kendra.connector.sdk.module.ConnectorConfiguration;
import com.amazonaws.kendra.connector.sdk.module.ConnectorModule;
import org.springframework.boot.logging.LogLevel;

/**
 * AEM connector main class.
 *
 * @author omkar_phadtare
 */
public class AemConnector {

  /**
   * Main method to start connector flow.
   *
   * @param args Input parameter.
   */
  public static void main(String[] args) {
    final ConnectorModule connectorModule =
        ConnectorModule.builder()
            .repositoryClientFactory(new AemClientFactory())
            .connectorName(AEM_CONNECTOR)
            .connectorConfiguration(
                ConnectorConfiguration.builder()
                    .loggingLevel(LogLevel.INFO)
                    .maxDocumentsPerCrawl(MAX_DOCS_PER_CRAWL)
                    .serverPortNumber(SERVER_PORT_NUMBER)
                    .numberOfThreads(THREAD_COUNT)
                    .build())
            .build();

    new Application().start(connectorModule);
  }
}