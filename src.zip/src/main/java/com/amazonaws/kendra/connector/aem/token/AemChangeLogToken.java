package com.amazonaws.kendra.connector.aem.token;

import com.amazonaws.kendra.connector.sdk.model.repository.RepositoryConfiguration;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Jdbc change log token.
 *
 * @author omkar_phadtare
 */
@Builder
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AemChangeLogToken {

  private long lastCrawlTime;
  private Map<String, RepositoryConfiguration> repositoryConfigurations;
  private Map<String, Object> additionalProperties;
  private List<RepositoryConfiguration.FieldMapping> fieldMappings;
  private List<String> inclusionPatterns;
  private List<String> exclusionPatterns;
}