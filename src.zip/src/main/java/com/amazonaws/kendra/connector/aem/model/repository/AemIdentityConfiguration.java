package com.amazonaws.kendra.connector.aem.model.repository;

import com.amazonaws.kendra.connector.sdk.model.repository.IdentityStoreConfiguration;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Value;

/**
 * This is the IdentityConfiguration class.
 *
 * @author ritika_raina
 */
@Value
@AllArgsConstructor(staticName = "of")
public class AemIdentityConfiguration {

  public static final String ENTERPRISE_ID = "enterpriseId";
  public static final String CONFIG = "config";
  public static final String CLIENT_ID = "clientID";
  public static final String CLIENT_SECRET = "clientSecret";
  public static final String APPAUTH = "appAuth";
  public static final String PUBLIC_KEY_ID = "publicKeyID";
  public static final String PRIVATE_KEY = "privateKey";
  public static final String PASS_PHRASE = "passphrase";

  IdentityStoreConfiguration identityStoreConfiguration;

  /**
   * Method to fetch box configuration.
   *
   * @return BoxConfig
   */
  public BoxConfig boxConfig() {
    return new BoxConfig(getClientId(), getClientSecret(), getEnterpriseId(),
        getPublicKeyId(), getPrivateKey(), getPassphrase());
  }

  /**
   * Fetch Enterprise Id from repository configuration.
   *
   * @return get enterpriseId.
   */
  public String getEnterpriseId() {
    return this.identityStoreConfiguration
        .getConnectionConfiguration()
        .getRepositoryEndpointMetadata()
        .get(ENTERPRISE_ID);
  }

  /**
   * Fetch Client Id from repository configuration.
   *
   * @return get clientID
   */
  public String getClientId() {
    Map<String, String> repositoryCredentials =
        this.identityStoreConfiguration.getConnectionConfiguration().getRepositoryCredentials();
    return repositoryCredentials.get(CLIENT_ID);
  }

  /**
   * Fetch Client Secret from repository configuration.
   *
   * @return get client Secret
   */
  public String getClientSecret() {
    Map<String, String> repositoryCredentials =
        this.identityStoreConfiguration.getConnectionConfiguration().getRepositoryCredentials();
    return repositoryCredentials.get(CLIENT_SECRET);
  }

  /**
   * Fetch Public Key Id from repository configuration.
   *
   * @return get public key id
   */
  public String getPublicKeyId() {
    Map<String, String> repositoryCredentials =
        this.identityStoreConfiguration.getConnectionConfiguration().getRepositoryCredentials();
    return repositoryCredentials.get(PUBLIC_KEY_ID);
  }

  /**
   * Fetch Private Key from repository configuration.
   *
   * @return get private key
   */
  public String getPrivateKey() {
    Map<String, String> repositoryCredentials =
        this.identityStoreConfiguration.getConnectionConfiguration().getRepositoryCredentials();
    return repositoryCredentials.get(PRIVATE_KEY);
  }

  /**
   * Fetch PassPhrase from repository configuration.
   *
   * @return get passphrase
   */
  public String getPassphrase() {
    Map<String, String> repositoryCredentials =
        this.identityStoreConfiguration.getConnectionConfiguration().getRepositoryCredentials();
    return repositoryCredentials.get(PASS_PHRASE);
  }
}