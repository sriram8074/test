package com.amazonaws.kendra.connector.aem.token;

import com.amazonaws.kendra.connector.aem.model.enums.ErrorDefinition;
import com.amazonaws.kendra.connector.sdk.exception.InternalServerError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.NonNull;

/**
 * Jdbc token serializer.
 *
 * @author omkar_phadtare
 */
@Builder
public class AemChangeLogTokenSerializer {

  @NonNull
  private ObjectMapper objectMapper;

  /**
   * Method to serialize the document comments.
   *
   * @param changeLogToken input parameter
   * @return returning siring value.
   * @throws InternalServerError when JsonProcessingException
   */
  public String serialize(AemChangeLogToken changeLogToken) {
    final AemChangeLogToken jdbcChangeLogToken = changeLogToken;
    try {
      return this.objectMapper.writeValueAsString(jdbcChangeLogToken);
    } catch (JsonProcessingException ex) {
      String errorMessage =
          "JDBC Connector error code: " + ErrorDefinition.ERROR_SERIALIZING_CL_TOKEN.getErrorCode()
              + System.lineSeparator() + "Error message: "
              + ErrorDefinition.ERROR_SERIALIZING_CL_TOKEN.getErrorMessage();
      throw new InternalServerError(errorMessage);
    }
  }

  /**
   * Method to deSerialize the document comments.
   *
   * @param string input parameter
   * @return returning siring value.
   * @throws InternalServerError when JsonProcessingException
   */
  public AemChangeLogToken deSerialize(String string) {
    try {
      return this.objectMapper.readValue(string, AemChangeLogToken.class);
    } catch (JsonProcessingException ex) {
      String errorMessage =
          "JDBC Connector error code: "
              + ErrorDefinition.ERROR_DESERIALIZING_CL_TOKEN.getErrorCode()
              + System.lineSeparator() + "Error message: "
              + ErrorDefinition.ERROR_DESERIALIZING_CL_TOKEN.getErrorMessage();
      throw new InternalServerError(errorMessage);
    }
  }
}