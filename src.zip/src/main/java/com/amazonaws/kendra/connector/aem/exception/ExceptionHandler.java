package com.amazonaws.kendra.connector.aem.exception;

import com.amazonaws.kendra.connector.sdk.exception.BadRequestException;
import com.amazonaws.kendra.connector.sdk.exception.ContinuableBadRequestException;
import com.amazonaws.kendra.connector.sdk.exception.ContinuableInternalServerError;
import com.amazonaws.kendra.connector.sdk.exception.InternalServerError;
import com.amazonaws.kendra.connector.sdk.exception.KendraConnectorException;
import lombok.extern.slf4j.Slf4j;

/**
 * Class for handling exceptions.
 *
 * @author omkar_phadtare
 */
@Slf4j
public class ExceptionHandler {

  private ExceptionHandler() {
  }

  /**
   * Method to bad request exception.
   *
   * @param e             parameter.
   * @param isContinuable input parameter
   * @return KendraConnectorException
   */
  private static KendraConnectorException handleAemException(
      Exception e, boolean isContinuable) {
    return isContinuable ? new ContinuableBadRequestException(e.getMessage()) :
        new BadRequestException(e.getMessage());
  }

  /**
   * Method to handle service unavailable exception.
   *
   * @param e             parameter.
   * @param isContinuable input parameter
   * @return KendraConnectorException
   */
  private static KendraConnectorException handleServiceUnavailableException(
      Exception e, boolean isContinuable) {
    return isContinuable ? new ContinuableInternalServerError(
        e.getMessage()) : new InternalServerError(
        e.getMessage());
  }
}