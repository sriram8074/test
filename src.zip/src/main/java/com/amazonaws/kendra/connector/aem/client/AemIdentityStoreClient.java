package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.aem.model.repository.AemIdentityConfiguration;
import com.amazonaws.kendra.connector.sdk.client.IdentityStoreClient;
import com.amazonaws.kendra.connector.sdk.model.principal.GroupInfo;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupMembersRequest;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupMembersResponse;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupsRequest;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupsResponse;
import com.amazonaws.kendra.connector.sdk.model.repository.IdentityStoreConfiguration;

/**
 * This is the IdentityStoreClient class.
 *
 * @author
 */
public class AemIdentityStoreClient implements IdentityStoreClient {

  private AemIdentityConfiguration aemIdentityConfiguration;
  private AemIdentityService aemIdentityService;


  @Override
  public ListGroupMembersResponse listGroupMembers(
      ListGroupMembersRequest listGroupMembersRequest) {
    GroupInfo groupInfo = listGroupMembersRequest.getGroupInfo();
    String cursor = listGroupMembersRequest.getToken();
    int limit = listGroupMembersRequest.getMaxNumberOfMembersToReturn();
    return aemIdentityService.buildGroupMembersForIdentityCrawler(
        groupInfo.getGroup(), cursor, limit);
  }

  @Override
  public ListGroupsResponse listGroups(ListGroupsRequest listGroupsRequest) {
    int limit = listGroupsRequest.getMaxNumberOfGroupsToReturn();
    String cursor = listGroupsRequest.getToken();
    return aemIdentityService.buildGroupsForIdentityCrawler(cursor, limit);
  }

  @Override
  public void resetAndInitialize(IdentityStoreConfiguration identityStoreConfiguration) {
    this.aemIdentityConfiguration = aemIdentityConfiguration.of(identityStoreConfiguration);
    this.aemIdentityService = new AemIdentityService(aemIdentityConfiguration);
  }
}