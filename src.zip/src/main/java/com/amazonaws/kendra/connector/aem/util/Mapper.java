package com.amazonaws.kendra.connector.aem.util;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Object mapper class.
 *
 * @author omkar_phadtare
 */
public class Mapper {

  private final ObjectMapper objectMapper = new ObjectMapper();

  private Mapper() {
  }

  public static Mapper getInstance() {
    return Holder.INSTANCE;
  }

  public ObjectMapper getObjectMapper() {
    return this.objectMapper;
  }

  private static class Holder {
    private static final Mapper INSTANCE = new Mapper();
  }
}