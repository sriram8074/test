package com.amazonaws.kendra.connector.aem.util;

import com.amazonaws.kendra.connector.sdk.exception.BadRequestException;
import java.net.InetAddress;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

/**
 * This is the Address Validator class.
 *
 * @author omkar_phadtare
 */
@Slf4j
public class AddressValidation {

  public AddressValidation() {
  }

  /**
   * Validates the InetAddress and throws if the address is any of the following: 1. Link Local
   * Address 2. Loopback
   * Address 3. Multicast Address 4. Any Local Address 5. Site Local Address
   *
   * @param address            the {@link InetAddress} to validate.
   * @param isServerlessAurora flag if db is on serverless Aurora
   * @throws BadRequestException if the address is invalid.
   */
  public static void validateInetAddress(@NonNull final InetAddress address,
      boolean isServerlessAurora) {
    boolean siteLocalCheck = isServerlessAurora ? Boolean.FALSE : address.isSiteLocalAddress();
    if (address.isMulticastAddress() || address.isAnyLocalAddress() || address.isLinkLocalAddress()
        || siteLocalCheck || address.isLoopbackAddress()) {
      throw new BadRequestException("Invalid URI");
    }
  }
}