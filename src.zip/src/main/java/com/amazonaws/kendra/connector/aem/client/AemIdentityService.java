package com.amazonaws.kendra.connector.aem.client;

import java.util.Arrays;
import java.util.List;

import com.amazonaws.kendra.connector.sdk.model.principal.Group;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupMembersResponse;
import com.amazonaws.kendra.connector.sdk.model.principal.ListGroupsResponse;

public class AemIdentityService {
    private List<Integer> waitTimeList = Arrays.asList(1, 5, 10, 15, 20, 40, 60);
    
	public ListGroupsResponse buildGroupsForIdentityCrawler(String cursor, int limit) {
		
		return null;
	}

	public ListGroupMembersResponse buildGroupMembersForIdentityCrawler(Group group, String cursor, int limit) {
		
		return null;
	}

}
