package com.amazonaws.kendra.connector.aem.model.item;

import static com.amazonaws.kendra.connector.aem.util.Constants.TIMESTAMP;
import static com.amazonaws.kendra.connector.aem.util.Constants.TIMEZONE;
import static java.util.stream.Collectors.toList;

import com.amazonaws.kendra.connector.aem.model.enums.AssetDataSourceField;
import com.amazonaws.kendra.connector.aem.model.enums.Entity;
import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.kendra.connector.sdk.exception.BadRequestException;
import com.amazonaws.kendra.connector.sdk.exception.InternalServerError;
import com.amazonaws.kendra.connector.sdk.model.item.Item;
import com.amazonaws.kendra.connector.sdk.model.repository.RepositoryConfiguration;
import com.amazonaws.services.kendra.model.ContentType;
import com.amazonaws.services.kendra.model.DocumentAttribute;
import com.amazonaws.services.kendra.model.DocumentAttributeValue;
import com.amazonaws.services.kendra.model.Principal;
import com.amazonaws.util.CollectionUtils;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;
import java.util.function.Function;
import lombok.Builder;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


/**
 * Item class for assets.
 *
 * @author Nitin
 */
@Value
@Builder(toBuilder = true)
@Slf4j
public class AssetItem implements Item {
  private String name;
  private InputStream inputStream;
  private List<Principal> principals;
  private AemConfiguration aemConfiguration;
  private String aemAssetUuid;
  private String aemAssetTitle;
  private String aemAssetSourceUri;
  private String aemAssetCreatedBy;
  private String aemAssetType;
  private String aemAssetCreatedAt;
  private String aemAssetLastModified;
  private String aemAssetPath;
  private Map<String,String> customMetadata;

  private Map<AssetDataSourceField, Function<RepositoryConfiguration.FieldMapping, String>>
      dataSourceAttributeBuilders =
      new ImmutableMap.Builder<AssetDataSourceField,
          Function<RepositoryConfiguration.FieldMapping,
              String>>()
          .put(AssetDataSourceField.aem_asset_title, this::getAem_asset_title)
          .put(AssetDataSourceField.aem_asset_source_uri, this::getAem_asset_source_uri)
          .put(AssetDataSourceField.aem_asset_createdBy, this::getAem_asset_createdBy)
          .put(AssetDataSourceField.aem_asset_type, this::getAem_asset_type)
          .put(AssetDataSourceField.aem_asset_createdAt, this::getAem_asset_createdAt)
          .put(AssetDataSourceField.aem_asset_lastModified, this::getAem_asset_lastModified)
          .build();


  private String getAem_asset_lastModified(RepositoryConfiguration.FieldMapping fieldMapping) {
    String aemAssetLastModified = this.aemAssetLastModified;
    if (!StringUtils.isEmpty(aemAssetLastModified)) {
      DateFormat originalFormat = new SimpleDateFormat(TIMESTAMP, Locale.ENGLISH);
      Date createdDate = null;
      try {
        createdDate = originalFormat.parse(aemAssetLastModified);
      } catch (ParseException e) {
        log.warn("Cannot parse requested value : {} to Date", aemAssetLastModified);
      }
      DateFormat dateFormat = new SimpleDateFormat(fieldMapping.getDateFieldFormat());
      dateFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
      return dateFormat.format(createdDate);
    }
    return null;
  }

  private String getAem_asset_createdAt(RepositoryConfiguration.FieldMapping fieldMapping) {
    String aemAssetCreatedAt = this.aemAssetCreatedAt;
    if (!StringUtils.isEmpty(aemAssetCreatedAt)) {
      DateFormat originalFormat = new SimpleDateFormat(TIMESTAMP, Locale.ENGLISH);
      Date createdDate = null;
      try {
        createdDate = originalFormat.parse(aemAssetCreatedAt);
      } catch (ParseException e) {
        log.warn("Cannot parse requested value : {} to Date", aemAssetCreatedAt);
      }
      DateFormat dateFormat = new SimpleDateFormat(fieldMapping.getDateFieldFormat());
      dateFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
      return dateFormat.format(createdDate);
    }
    return null;
  }

  private String getAem_asset_type(RepositoryConfiguration.FieldMapping fieldMapping) {
    if (!StringUtils.isEmpty(this.aemAssetType)) {
      return this.aemAssetType;
    }
    return null;
  }

  private String getAem_asset_createdBy(RepositoryConfiguration.FieldMapping fieldMapping) {
    if (!StringUtils.isEmpty(this.aemAssetCreatedBy)) {
      return this.aemAssetCreatedBy;
    }
    return null;
  }

  private String getAem_asset_source_uri(RepositoryConfiguration.FieldMapping fieldMapping) {
    if (!StringUtils.isEmpty(this.aemAssetSourceUri)) {
      return this.aemAssetSourceUri;
    }
    return null;
  }

  private String getAem_asset_title(RepositoryConfiguration.FieldMapping fieldMapping) {
    if (!StringUtils.isEmpty(this.aemAssetTitle)) {
      return this.aemAssetTitle;
    }
    return null;
  }

  public Optional<String> getChangeDetectionToken() {
    return Optional.of(String.valueOf(this.aemAssetLastModified));
  }

  @Override
  public String getDocumentId() {
    return this.aemAssetPath;
  }

  @Override
  public InputStream getDocumentBody() {
    try {
      InputStream targetStream = new ByteArrayInputStream(getDocumentTitle().getBytes(
          StandardCharsets.UTF_8));
      return targetStream;
    } catch (Exception e) {
      throw new BadRequestException("Error in building input stream of file object", e);
    }
  }

  @Override
  public String getDocumentTitle() {
    return this.aemAssetTitle;
  }

  @Override
  public ContentType getContentType() {
    return null;
  }

  @Override
  public List<DocumentAttribute> getDocumentAttributes() {
    List<RepositoryConfiguration.FieldMapping> fieldMappings = null;
    if (!Objects.isNull(aemConfiguration.getRepositoryConfiguration()
        .getRepositoryConfigurations())) {
      fieldMappings =
          !Objects.isNull(
              aemConfiguration.getRepositoryConfiguration().getRepositoryConfigurations()
                  .get(Entity.ASSET.getEntityName()))
              ? aemConfiguration.getRepositoryConfiguration().getRepositoryConfigurations()
              .get(Entity.ASSET.getEntityName())
              .getFieldMappings() :
              new ArrayList<RepositoryConfiguration.FieldMapping>();
    }

    if (CollectionUtils.isNullOrEmpty(fieldMappings)) {
      return ImmutableList.of();
    }
    return fieldMappings.stream().map(this::createFieldMapping).filter(Optional::isPresent)
        .map(Optional::get).collect(toList());
  }

  private Optional<DocumentAttribute> createFieldMapping(
      final RepositoryConfiguration.FieldMapping fieldMapping) {
    if (Arrays.stream(AssetDataSourceField.values())
        .noneMatch(
            datasourceField -> datasourceField.name()
                .equals(fieldMapping.getDataSourceFieldName()))) {
      return this.getCustomAttribute(fieldMapping);
    }
    return this.getGenericAttr(fieldMapping);
  }

  private Optional<DocumentAttribute> getGenericAttr(
      final RepositoryConfiguration.FieldMapping fieldMapping) {

    return Optional.ofNullable(fieldMapping).map(li -> fieldMapping.getDataSourceFieldName())
        .map(dataSourceFieldName -> this.dataSourceAttributeBuilders
            .get(AssetDataSourceField.valueOf(dataSourceFieldName))
            .apply(fieldMapping))
        .map(dataSourceFieldValue -> this.createDocumentAttributeValue(fieldMapping,
            dataSourceFieldValue))
        .map(documentAttributeValue -> new DocumentAttribute()
            .withKey(fieldMapping.getIndexFieldName()).withValue(documentAttributeValue));
  }

  /**
   * Method to return Document Attribute Value.
   *
   * @param fieldMapping input param
   * @param value        input param
   * @return DocumentAttributeValue
   */

  public final DocumentAttributeValue createDocumentAttributeValue(
      final RepositoryConfiguration.FieldMapping fieldMapping,
      final String value) {
    if (fieldMapping.getIndexFieldType().equals(RepositoryConfiguration.IndexFieldType.STRING)) {
      return new DocumentAttributeValue().withStringValue(value);
    } else if (fieldMapping.getIndexFieldType()
        .equals(RepositoryConfiguration.IndexFieldType.STRING_LIST)) {
      return new DocumentAttributeValue().withStringListValue(value);
    } else if (fieldMapping.getIndexFieldType()
        .equals(RepositoryConfiguration.IndexFieldType.LONG)) {
      try {
        return new DocumentAttributeValue()
            .withLongValue((long) (Double.parseDouble(value)));
      } catch (NumberFormatException ex) {
        log.warn("Cannot parse requested value : {} to long", value);
        return null;
      }
    } else if (fieldMapping.getIndexFieldType()
        .equals(RepositoryConfiguration.IndexFieldType.DATE)) {
      try {
        return new DocumentAttributeValue()
            .withDateValue(new SimpleDateFormat(fieldMapping.getDateFieldFormat()).parse(value));
      } catch (Exception ex) {
        log.warn("Cannot parse requested value : {} to date", value);
        return null;
      }
    } else {
      throw new InternalServerError(
          "Only String, String List, Date and Long formats are supported for field mappings");
    }
  }

  private Optional<DocumentAttribute> getCustomAttribute(
      final RepositoryConfiguration.FieldMapping fieldMapping) {
    if (com.amazonaws.util.StringUtils.isNullOrEmpty(this.customMetadata
            .get(fieldMapping.getDataSourceFieldName()))) {
      return Optional.empty();
    }
    Optional<String> attributeV = Optional
        .ofNullable(this.customMetadata.get(fieldMapping.getDataSourceFieldName()));
    return attributeV.map(
        customAttrV -> new DocumentAttribute().withKey(fieldMapping.getIndexFieldName())
            .withValue(new DocumentAttributeValue().withStringValue(customAttrV)));
  }

  @Override
  public List<Principal> getPrincipals() {
    return this.principals;
  }
}