package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.kendra.connector.aem.services.AemService;
import com.amazonaws.kendra.connector.sdk.model.item.ItemInfo;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * AEM Iterator class.
 *
 * @author omkar_phadtare
 */
public class AemChangeLogIterator implements AemIterator {
  private final Queue<ItemInfo> itemInfoQueue;
  private final AemConfiguration aemConfiguration;
  private final AemService aemService;

  /**
   * Constructor.
   */
  public AemChangeLogIterator(AemService aemService, AemConfiguration aemConfiguration) {
    this.aemService = aemService;
    this.aemConfiguration = aemConfiguration;
    this.itemInfoQueue = new ConcurrentLinkedQueue<>();
  }

  @Override
  public boolean hasNext() {
    return Boolean.TRUE;
  }

  @Override
  public ItemInfo next() {
    return this.itemInfoQueue.remove();
  }

  @Override
  public void initialize() {
  }
}