package com.amazonaws.kendra.connector.aem.client;

import static com.amazonaws.kendra.connector.aem.util.Constants.CHANGE_LOG;
import static com.amazonaws.kendra.connector.aem.util.Constants.FULL_CRAWL;

import com.amazonaws.kendra.connector.aem.model.repository.AemConfiguration;
import com.amazonaws.kendra.connector.aem.services.AemService;

/**
 * Iterator class for AEM connector.
 *
 * @author omkar_phadtare
 */
public final class AemIteratorFactory {

  private AemIteratorFactory() {
  }

  /**
   * Gets instance.
   *
   * @param crawlMode        input parameter
   * @param aemConfiguration input parameter
   * @param aemService       input parameter
   * @return AemIterator
   */
  public static AemIterator getInstance(String crawlMode, AemConfiguration aemConfiguration,
      AemService aemService) {
    if (FULL_CRAWL.equalsIgnoreCase(crawlMode)) {
      return new AemFullCrawlIterator(aemService, aemConfiguration);
    } else if (CHANGE_LOG.equalsIgnoreCase(crawlMode)) {
      return new AemChangeLogIterator(aemService, aemConfiguration);
    } else {
      return null;
    }
  }
}