package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.sdk.model.item.ItemInfo;
import java.util.Iterator;

/**
 * AEM iterator.
 *
 * @author omkar_phadtare
 */
public interface AemIterator extends Iterator<ItemInfo> {
  /**
   * Initialize.
   */
  default void initialize() {
  }

  /**
   * Initialize.
   *
   * @param aemChangeLogToken the aem change log token
   */
  default void initialize(final String aemChangeLogToken) {
  }
}