package com.amazonaws.kendra.connector.aem.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Entity enum.
 *
 * @author omkar_phadtare
 */
@AllArgsConstructor
public enum Entity {
  ASSET("asset"),
  PAGE("page");

  @Getter
  private final String name;

  public String getEntityName() {
    return this.name;
  }
}