package com.amazonaws.kendra.connector.aem.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Error Definition enum.
 *
 * @author omkar_phadtare
 */
@AllArgsConstructor
@Getter
public enum ErrorDefinition {
  ERROR_SERIALIZING_CL_TOKEN(5300, "Error in serializing change log token."),
  ERROR_DESERIALIZING_CL_TOKEN(5301, "Error in de-serializing change log token.");

  public final int errorCode;
  public final String errorMessage;
}