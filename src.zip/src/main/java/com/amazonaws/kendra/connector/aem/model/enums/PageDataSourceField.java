package com.amazonaws.kendra.connector.aem.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enum for datasource fields of pages.
 *
 * @author omkar_phadtare
 */
@AllArgsConstructor
public enum PageDataSourceField {
  aem_page_source_uri("aem_page_source_uri"),
  aem_page_createdBy("aem_page_createdBy"),
  aem_page_lastReplicatedBy("aem_page_lastReplicatedBy"),
  aem_page_template("aem_page_template"),
  aem_entity_type("aem_entity_type"),
  aem_page_createdAt("aem_page_createdAt"),
  aem_page_lastModified("aem_page_lastModified");

  @Getter
  private final String type;
}