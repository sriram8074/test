package com.amazonaws.kendra.connector.aem.util;

import com.amazonaws.kendra.connector.aem.model.enums.ErrorDefinition;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * Utility class for AEM connector.
 *
 * @author omkar_phadtare
 */
@Slf4j
public class CommonUtil {

  /**
   * Method to return error message based on given error definition.
   *
   * @param errorDefinition input parameter
   * @param solution        input parameter
   * @return error message
   */
  public static String getErrorMessage(ErrorDefinition errorDefinition, String solution) {
    return "AEM Connector error code: " + errorDefinition.getErrorCode()
        + System.lineSeparator() + "Error message: " + errorDefinition.getErrorMessage()
        + System.lineSeparator() + "Exception from driver/connector: " + solution;
  }

}
