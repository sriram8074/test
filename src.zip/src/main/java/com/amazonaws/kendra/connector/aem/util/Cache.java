package com.amazonaws.kendra.connector.aem.util;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This is the Cache class.
 *
 * @author omkar_phadtare
 */
public class Cache {

  private final LinkedHashMap<String, Object> documentBlobContent;

  /**
   * Cache.
   *
   * @param capacity input parameter
   */
  public Cache(int capacity) {

    documentBlobContent = new LinkedHashMap<>(capacity, 0.99F, false) {

      @Override
      protected boolean removeEldestEntry(Map.Entry<String, Object> eldest) {
        return size() > capacity;
      }
    };
  }

  public void cacheDocumentBlobContent(String key, Object value) {
    documentBlobContent.put(key, value);
  }

  public Object getDocumentBlobContent(String key) {
    return documentBlobContent.remove(key);
  }
}