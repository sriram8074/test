package com.amazonaws.kendra.connector.aem.util;



import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Getter;

/**
 * This is the JdbcCollaborationInfo class.
 *
 * @author omkar_phadtare
 */
@Getter
public class AemCollaborationInfo {

  private List<String> allowGroups;
  private List<String> allowUsers;
  private List<String> denyGroups;
  private List<String> denyUsers;

  /**
   * AemCollaborationInfo class constructor.
   *
   */
  public AemCollaborationInfo() {
    this.allowGroups = new ArrayList<>();
    this.allowUsers = new ArrayList<>();
    this.denyGroups = new ArrayList<>();
    this.denyUsers = new ArrayList<>();
  }

  /**
   * Method to add user email.
   *
   * @param userEmail input parameter
   */
  public void addAllowUser(String userEmail) {
    if (Objects.nonNull(allowUsers)) {
      allowUsers.add(userEmail);
    }
  }

  /**
   * Method to add user email.
   *
   * @param groupName input parameter
   */
  public void addAllowGroup(String groupName) {
    if (Objects.nonNull(allowGroups)) {
      allowGroups.add(groupName);
    }
  }

  /**
   * Method to add user email.
   *
   * @param userEmail input parameter
   */
  public void addDenyUser(String userEmail) {
    if (Objects.nonNull(denyUsers)) {
      denyUsers.add(userEmail);
    }
  }

  /**
   * Method to add user email.
   *
   * @param groupName input parameter
   */
  public void addDenyGroup(String groupName) {
    if (Objects.nonNull(denyGroups)) {
      denyGroups.add(groupName);
    }
  }
}