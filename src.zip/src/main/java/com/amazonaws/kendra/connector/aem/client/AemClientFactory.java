package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.sdk.client.RepositoryClient;
import com.amazonaws.kendra.connector.sdk.client.RepositoryClientFactory;

/**
 * Factory class for AEM connector.
 *
 * @author omkar_phadtare
 */
public class AemClientFactory implements RepositoryClientFactory {

  @Override
  public RepositoryClient create() {
    return new AemClient();
  }
}