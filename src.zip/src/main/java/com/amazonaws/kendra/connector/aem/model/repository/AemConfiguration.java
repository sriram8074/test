package com.amazonaws.kendra.connector.aem.model.repository;

import static com.amazonaws.kendra.connector.aem.util.Constants.AEM_URL;
import static com.amazonaws.kendra.connector.aem.util.Constants.ASSET_NAME_EXCLUSION_PATTERNS;
import static com.amazonaws.kendra.connector.aem.util.Constants.ASSET_NAME_INCLUSION_PATTERNS;
import static com.amazonaws.kendra.connector.aem.util.Constants.ASSET_ROOT_PATHS;
import static com.amazonaws.kendra.connector.aem.util.Constants.AUTH_TYPE;
import static com.amazonaws.kendra.connector.aem.util.Constants.CLIENT_ID;
import static com.amazonaws.kendra.connector.aem.util.Constants.CLIENT_SECRET;
import static com.amazonaws.kendra.connector.aem.util.Constants.CRAWL_ASSETS;
import static com.amazonaws.kendra.connector.aem.util.Constants.CRAWL_PAGES;
import static com.amazonaws.kendra.connector.aem.util.Constants.CUSTOM_SCOPE_NAME;
import static com.amazonaws.kendra.connector.aem.util.Constants.EMPTY_STRING;
import static com.amazonaws.kendra.connector.aem.util.Constants.PAGE_COMPONENTS;
import static com.amazonaws.kendra.connector.aem.util.Constants.PAGE_NAME_EXCLUSION_PATTERNS;
import static com.amazonaws.kendra.connector.aem.util.Constants.PAGE_NAME_INCLUSION_PATTERNS;
import static com.amazonaws.kendra.connector.aem.util.Constants.PAGE_ROOT_PATHS;
import static com.amazonaws.kendra.connector.aem.util.Constants.PASSWORD;
import static com.amazonaws.kendra.connector.aem.util.Constants.PRIVATE_KEY;
import static com.amazonaws.kendra.connector.aem.util.Constants.USERNAME;

import com.amazonaws.kendra.connector.aem.model.enums.Entity;
import com.amazonaws.kendra.connector.sdk.exception.BadRequestException;
import com.amazonaws.kendra.connector.sdk.model.repository.RepositoryConfiguration;
import com.amazonaws.util.CollectionUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Value;

/**
 * Configuration class for AEM connector.
 *
 * @author omkar_phadtare
 */
@Value
@AllArgsConstructor(staticName = "of")
public class AemConfiguration {

  RepositoryConfiguration repositoryConfiguration;

  /**
   * Fetch AEM username from repository configuration.
   *
   * @return AEM username.
   */
  public String getUsername() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(USERNAME).toString();
  }

  /**
   * Fetch AEM password from repository configuration.
   *
   * @return AEM password.
   */
  public String getPassword() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(PASSWORD).toString();
  }

  /**
   * Fetch AEM client ID from repository configuration.
   *
   * @return AEM client ID.
   */
  public String getClientId() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(CLIENT_ID).toString();
  }

  /**
   * Fetch AEM client secret from repository configuration.
   *
   * @return AEM client secret.
   */
  public String getClientSecret() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(CLIENT_SECRET).toString();
  }

  /**
   * Fetch AEM private key from repository configuration.
   *
   * @return AEM private key.
   */
  public String getPrivateKey() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(PRIVATE_KEY).toString();
  }

  /**
   * Fetch AEM custom scope name from repository configuration.
   *
   * @return AEM custom scope name.
   */
  public String getCustomScopeName() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryCredentials()
        .get(CUSTOM_SCOPE_NAME).toString();
  }

  /**
   * Fetch AEM url from repository configuration.
   *
   * @return AEM url.
   */
  public String getAemUrl() {
    return repositoryConfiguration.getConnectionConfiguration().getRepositoryEndpointMetadata()
        .get(AEM_URL).toString();
  }

  /**
   * Method to fetch crawl type from repository configuration.
   *
   * @return crawl type.
   */
  public String getCrawlType() {
    return Objects.isNull(repositoryConfiguration.getCrawlType()) ? EMPTY_STRING :
        repositoryConfiguration.getCrawlType().toString();
  }

  /**
   * Fetch assets field_mapping from repository configuration.
   *
   * @return assets field_mapping
   */
  public List<RepositoryConfiguration.FieldMapping> getAssetsFieldMappings() {
    RepositoryConfiguration assetEntity;
    Map<String, RepositoryConfiguration> repositoryConfigurations =
        this.repositoryConfiguration.getRepositoryConfigurations();
    assetEntity = repositoryConfigurations.get(Entity.ASSET.getName().toLowerCase());
    return CollectionUtils.isNullOrEmpty(
        assetEntity
            .getFieldMappings()) ? new ArrayList<>() :
        assetEntity.getFieldMappings();
  }

  /**
   * Fetch pages field_mapping from repository configuration.
   *
   * @return pages field_mapping
   */
  public List<RepositoryConfiguration.FieldMapping> getPageFieldMappings() {
    RepositoryConfiguration assetEntity;
    Map<String, RepositoryConfiguration> repositoryConfigurations =
        this.repositoryConfiguration.getRepositoryConfigurations();
    assetEntity = repositoryConfigurations.get(Entity.ASSET.getName().toLowerCase());
    return CollectionUtils.isNullOrEmpty(
        assetEntity
            .getFieldMappings()) ? new ArrayList<>() :
        assetEntity.getFieldMappings();
  }

  /**
   * Fetch repository_configuration.
   */
  public Map<String, RepositoryConfiguration> getRepositoryConfigurations() {
    return CollectionUtils
        .isNullOrEmpty(this.repositoryConfiguration
            .getRepositoryConfigurations().entrySet()) ? new HashMap<>() :
        this.repositoryConfiguration.getRepositoryConfigurations();
  }

  /**
   * Fetch Additional_properties from repository configuration.
   *
   * @return Additional_properties
   */
  public Map<String, Object> getAdditionalProperties() {
    return CollectionUtils
        .isNullOrEmpty(this.repositoryConfiguration
            .getAdditionalProperties().entrySet()) ? new HashMap<>() :
        this.repositoryConfiguration.getAdditionalProperties();
  }

  /**
   * Method to fetch auth type from repository configuration.
   *
   * @return auth type.
   */
  public String getAuthType() {
    return Objects.isNull(getAdditionalProperties().get(AUTH_TYPE)) ? EMPTY_STRING :
        getAdditionalProperties().get(AUTH_TYPE).toString();
  }

  /**
   * Fetch root paths from additional properties.
   *
   * @return page root paths.
   */
  public List<String> getPageRootPaths() {
    Object rootPaths = getAdditionalProperties().get(PAGE_ROOT_PATHS);
    if (rootPaths instanceof List<?>) {
      return (List<String>) rootPaths;
    } else {
      throw new BadRequestException("Root Paths must be a list of strings.");
    }
  }

  /**
   * Fetch root paths from additional properties.
   *
   * @return asset root paths.
   */
  public List<String> getAssetRootPaths() {
    Object rootPaths = getAdditionalProperties().get(ASSET_ROOT_PATHS);
    if (rootPaths instanceof List<?>) {
      return (List<String>) rootPaths;
    } else {
      throw new BadRequestException("Root Paths must be a list of strings.");
    }
  }


  /**
   * Fetch boolean - crawlPages from additional properties.
   *
   * @return crawlPages boolean.
   */
  public boolean crawlPages() {
    String crawlPages = String.valueOf(getAdditionalProperties().get(CRAWL_PAGES));
    return Boolean.parseBoolean(crawlPages);
  }

  /**
   * Fetch boolean - crawlAssets from additional properties.
   *
   * @return crawlAssets boolean.
   */
  public boolean crawlAssets() {
    String crawlAssets = String.valueOf(getAdditionalProperties().get(CRAWL_ASSETS));
    return Boolean.parseBoolean(crawlAssets);
  }

  /**
   * Fetch page name inclusion patterns from repository configuration.
   *
   * @return page name inclusion patterns.
   */
  public List<String> getPagePathInclusionPatterns() {
    Object pageNameIncPatterns = getAdditionalProperties().get(PAGE_NAME_INCLUSION_PATTERNS);
    if (Objects.nonNull(pageNameIncPatterns)) {
      if (pageNameIncPatterns instanceof List<?>) {
        return CollectionUtils.isNullOrEmpty((List<String>) pageNameIncPatterns) ? new ArrayList<>()
            : (List<String>) pageNameIncPatterns;
      } else {
        throw new BadRequestException("Page name inclusion patterns must be a list of strings.");
      }
    }
    return new ArrayList<>();
  }

  /**
   * Fetch page name exclusion patterns from repository configuration.
   *
   * @return page name exclusion patterns.
   */
  public List<String> getPagePathExclusionPatterns() {
    Object pageNameExcPatterns = getAdditionalProperties().get(PAGE_NAME_EXCLUSION_PATTERNS);
    if (Objects.nonNull(pageNameExcPatterns)) {
      if (pageNameExcPatterns instanceof List<?>) {
        return CollectionUtils.isNullOrEmpty((List<String>) pageNameExcPatterns) ? new ArrayList<>()
            : (List<String>) pageNameExcPatterns;
      } else {
        throw new BadRequestException("Page name exclusion patterns must be a list of strings.");
      }
    }
    return new ArrayList<>();
  }

  /**
   * Fetch asset name inclusion patterns from repository configuration.
   *
   * @return asset name inclusion patterns.
   */
  public List<String> getAssetPathInclusionPatterns() {
    Object assetNameIncPatterns = getAdditionalProperties().get(ASSET_NAME_INCLUSION_PATTERNS);
    if (Objects.nonNull(assetNameIncPatterns)) {
      if (assetNameIncPatterns instanceof List<?>) {
        return CollectionUtils.isNullOrEmpty((List<String>) assetNameIncPatterns)
            ? new ArrayList<>()
            : (List<String>) assetNameIncPatterns;
      } else {
        throw new BadRequestException("Asset name inclusion patterns must be a list of strings.");
      }
    }
    return new ArrayList<>();
  }

  /**
   * Fetch asset name exclusion patterns from repository configuration.
   *
   * @return asset name exclusion patterns.
   */
  public List<String> getAssetPathExclusionPatterns() {
    Object assetNameExcPatterns = getAdditionalProperties().get(ASSET_NAME_EXCLUSION_PATTERNS);
    if (Objects.nonNull(assetNameExcPatterns)) {
      if (assetNameExcPatterns instanceof List<?>) {
        return CollectionUtils.isNullOrEmpty((List<String>) assetNameExcPatterns)
            ? new ArrayList<>()
            : (List<String>) assetNameExcPatterns;
      } else {
        throw new BadRequestException("Asset name exclusion patterns must be a list of strings.");
      }
    }
    return new ArrayList<>();
  }

  /**
   * Fetch page components from repository configuration.
   *
   * @return page components.
   */
  public List<Map<String, Object>> getPageComponents() {
    return (List<Map<String, Object>>) this.repositoryConfiguration.getAdditionalProperties()
        .get(PAGE_COMPONENTS);
  }
}