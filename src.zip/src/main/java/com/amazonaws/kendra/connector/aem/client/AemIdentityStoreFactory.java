package com.amazonaws.kendra.connector.aem.client;

import com.amazonaws.kendra.connector.sdk.client.IdentityStoreClient;
import com.amazonaws.kendra.connector.sdk.client.IdentityStoreClientFactory;

/**
 * This is the IdentityStoreFactory class.
 *
 * @author ritika_raina
 */
public class AemIdentityStoreFactory implements IdentityStoreClientFactory {

  @Override
  public IdentityStoreClient create() {
    return new AemIdentityStoreClient();
  }
}
