package com.amazonaws.kendra.connector.aem.util;

/**
 * Constants class.
 *
 * @author omkar_phadtare
 */
public final class Constants {

  public static final String FILE = "file";
  public static final String AEM_CONNECTOR = "AEM";
  public static final String PAGE = "page";
  public static final String EMPTY_STRING = "";
  public static final String FULL_CRAWL = "FULL_CRAWL";
  public static final String CHANGE_LOG = "CHANGE_LOG";
  public static final String USERNAME = "username";
  public static final String PASSWORD = "password";
  public static final String AEM_URL = "aemUrl";
  public static final String PAGE_ROOT_PATHS = "pageRootPaths";
  public static final String ASSET_ROOT_PATHS = "assetRootPaths";
  public static final String CRAWL_ASSETS = "crawlAssets";
  public static final String CRAWL_PAGES = "crawlPages";
  public static final String PAGE_NAME_INCLUSION_PATTERNS = "pageInclusionPatterns";
  public static final String PAGE_NAME_EXCLUSION_PATTERNS = "pageExclusionPatterns";
  public static final String ASSET_NAME_INCLUSION_PATTERNS = "assetInclusionPatterns";
  public static final String ASSET_NAME_EXCLUSION_PATTERNS = "assetExclusionPatterns";
  public static final String PAGE_COMPONENTS = "pageComponents";
  public static final String AUTH_TYPE = "authType";
  public static final String CLIENT_ID = "clientId";
  public static final String CLIENT_SECRET = "clientSecret";
  public static final String PRIVATE_KEY = "privateKey";
  public static final String CUSTOM_SCOPE_NAME = "customScopeName";
  public static final String OAUTH = "OAuth";
  public static final String BASIC = "Basic";

  public static final int MAX_DOCS_PER_CRAWL = 1000;
  public static final int SERVER_PORT_NUMBER = 9000;
  public static final int THREAD_COUNT = 200;

  public static final String DEFAULT_PAGEROOTPATH = "/content";
  public static final String DEFAULT_ASSETROOTPATH = "/content/dam";
  public static final String PAGE_PATH = "page_path";
  public static final String ITEM_PRINCIPAL = "item_principal";
  public static final String TIMEZONE = "UST";
  public static final String TIMESTAMP = "EEE MMM dd yyyy HH:mm:ss";
  public static final String USER = "USER";
  public static final String GROUP = "GROUP";

}